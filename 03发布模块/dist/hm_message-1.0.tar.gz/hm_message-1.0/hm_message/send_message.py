def send(text):
    print("sending %s ..." % text)