def receive():
    return "this from 10xx message"